<?php

    require_once "conexao.php";

    //var_dump($_POST);

    $consulta = array();
    $consulta['nome'] = $_POST['nome'];
    $consulta['pet']   = $_POST['pet'];
    $consulta['telefone']   = $_POST['telefone'];
    $consulta['data']   = $_POST['data'];
    $consulta['hora']   = $_POST['hora'];

    if(isset($_GET['id'])){ //atualização dos dados
      $consulta['id'] = $_GET['id'];
      $sql = "UPDATE consulta SET nome = :nome, pet = :pet, telefone = :telefone, data = :data, hora = :hora WHERE id = :id";
    }else{
      $sql = "INSERT INTO consulta(nome, pet, telefone, data, hora) VALUES(:nome, :pet, :telefone, :data, :hora);";
    }
    //SQL INJECTION
    $query = $con->prepare($sql);
    $resultado = $query->execute($consulta);

    if($resultado == true){
      // echo "Dados foram inseridos com sucesso";
      header('Location: lista_consulta.php');
    }else{
      echo "Houve um erro ao tentar inserir os dados";
    }

?>
