<?php

    require_once 'conexao.php';
    $id = $_GET['id'];
    $sql = "DELETE FROM consulta WHERE id = " . $id;

    $resultado = $con->query($sql);
    if($resultado==true){
      //echo "Registro removido com sucesso";
      header('Location: lista_consulta.php');
    }else{
      echo "Erro ao tentar remover o registro: " . $id;
    }
 ?>
